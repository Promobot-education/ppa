/*!
 * \file promobot.h
 */

#ifndef PROMOBOT_H
#define PROMOBOT_H

#include <chrono>
#include <deque>
#include <map>
#include <string>
#include <vector>

#include "../json/json.hpp"
using json = nlohmann::json;

//! Generic namespace
namespace promobot
{
//! This enum describes the different locations that can be queried using method path().
/*!
 * \enum PromobotLocations
 */
enum class PromobotLocations
{
    Home,                   //!< User's home directory (the same as QDir::homePath()). On Unix systems, this is equal to the HOME environment variable
    Temp,                   //!< Directory where temporary files can be stored
    Work,                   //!< Work directory
    Resources,              //!< Resources directory
    Log,                    //!< Directory containing log files
    Applications,           //!< Directory containing installed applications on the robot
    Scripts,                //!< Directory containing the robot scripts files
    Faces,                  //!< Directory containing the faces database and images

    Music,                  //!< Directory containing the robot music or other audio files
    Pictures,               //!< Directory containing the robot pictures
    Photos,                 //!< Directory containing the robot photos
    Videos,                 //!< Directory containing the robot movies and videos
    BordersPhoto,           //!< Directory containing the border pictures for photos
    VideoMessages,          //!< Directory containing the video messages from visitors
    PeopleInfos,            //!< Directory containing the cards with information about visitors
    Documents,              //!< Directory containing the robot document files

    Answers,                //!< Directory containing the robot answers database
    PromoText,              //!< Directory containing the robot promo phrases
    GreetingText            //!< Directory containing the robot greeting phrases
};

//! Return directory where files of type belong.
/*!
 * \param location needed directory
 * \return path to needed directory
 */
std::string path( PromobotLocations location );

struct Buffer
{
    void *data;
    size_t size;
    size_t pos;
};

// выполнение команды и получение результата работы
std::string exec( const std::string &command );

// получить MD5-хэш
std::string getMD5( const std::string &message );

// получить список файлов в каталоге
bool getFiles( const std::string &dir, std::vector<std::string> &files );

// получение текущей даты
std::string getCurDate();

// получение текущего времени
std::string getCurTime();

// сравнение по времени
bool checkLastTime( const std::string &date, const std::string &time, const int &difference );

// запись лога
void addLog( const std::string &tag, const std::string &text );

// установить громкость микрофона
void setMicVolume( const int & );
int getMicVolume();

// выключить микрофон
void setMicMute( const bool & );

// установить громкость динамиков
void setSoundVolume( const int & );
int getSoundVolume();

// выключить динамики
void setSoundMute( const bool & );

// запись ответа от сервера в буфер
size_t reader( char *buf, size_t size, size_t nmemb, void *data );

// запись ответа от сервера в буфер
size_t writer( char *buf, size_t size, size_t nmemb, std::string *data );

bool loadJson( const std::string &filename, json *root );
bool saveJson( const std::string &filename, const json &root );

bool lidarConnected();

namespace strings
{
// смена регистра текста
std::string toLower( const std::string & );
std::string toUpper( const std::string & );

std::vector<std::string> splitString( const std::string &str, const std::string &delimeter = " " );
std::string joinString( const std::vector<std::string> &arr, const std::string &delimeter = " " );
}

namespace math
{
// преобразование величин
float remapFloat( float, const float &, const float &, const float &, const float & );

double getDeviation( const std::deque<double> &deque, const double &mean );

double getValue( const std::deque<double> &deque );

std::tuple<double, double> getTrendCoefs( const double &d_x, const std::deque<double> &deque );
std::tuple<double, double> getTrendCoefs( const std::map<double, double> &map );
}

}
using promobot::PromobotLocations;

#endif
