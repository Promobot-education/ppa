
"use strict";

let Bool = require('./Bool.js')
let Int8 = require('./Int8.js')
let Script = require('./Script.js')
let setServoCommand = require('./setServoCommand.js')
let setServoTorque = require('./setServoTorque.js')
let String = require('./String.js')

module.exports = {
  Bool: Bool,
  Int8: Int8,
  Script: Script,
  setServoCommand: setServoCommand,
  setServoTorque: setServoTorque,
  String: String,
};
