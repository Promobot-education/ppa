// Auto-generated. Do not edit!

// (in-package promobot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class ServoSmallState {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id = null;
      this.command = null;
      this.torque = null;
      this.setPoint_1 = null;
      this.setPoint_2 = null;
      this.state = null;
      this.motorsCurrent = null;
      this.capSensorVal = null;
    }
    else {
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = 0;
      }
      if (initObj.hasOwnProperty('command')) {
        this.command = initObj.command
      }
      else {
        this.command = 0;
      }
      if (initObj.hasOwnProperty('torque')) {
        this.torque = initObj.torque
      }
      else {
        this.torque = false;
      }
      if (initObj.hasOwnProperty('setPoint_1')) {
        this.setPoint_1 = initObj.setPoint_1
      }
      else {
        this.setPoint_1 = 0;
      }
      if (initObj.hasOwnProperty('setPoint_2')) {
        this.setPoint_2 = initObj.setPoint_2
      }
      else {
        this.setPoint_2 = 0;
      }
      if (initObj.hasOwnProperty('state')) {
        this.state = initObj.state
      }
      else {
        this.state = 0;
      }
      if (initObj.hasOwnProperty('motorsCurrent')) {
        this.motorsCurrent = initObj.motorsCurrent
      }
      else {
        this.motorsCurrent = 0;
      }
      if (initObj.hasOwnProperty('capSensorVal')) {
        this.capSensorVal = initObj.capSensorVal
      }
      else {
        this.capSensorVal = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ServoSmallState
    // Serialize message field [id]
    bufferOffset = _serializer.int16(obj.id, buffer, bufferOffset);
    // Serialize message field [command]
    bufferOffset = _serializer.uint16(obj.command, buffer, bufferOffset);
    // Serialize message field [torque]
    bufferOffset = _serializer.bool(obj.torque, buffer, bufferOffset);
    // Serialize message field [setPoint_1]
    bufferOffset = _serializer.int16(obj.setPoint_1, buffer, bufferOffset);
    // Serialize message field [setPoint_2]
    bufferOffset = _serializer.int16(obj.setPoint_2, buffer, bufferOffset);
    // Serialize message field [state]
    bufferOffset = _serializer.uint16(obj.state, buffer, bufferOffset);
    // Serialize message field [motorsCurrent]
    bufferOffset = _serializer.int16(obj.motorsCurrent, buffer, bufferOffset);
    // Serialize message field [capSensorVal]
    bufferOffset = _serializer.int16(obj.capSensorVal, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ServoSmallState
    let len;
    let data = new ServoSmallState(null);
    // Deserialize message field [id]
    data.id = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [command]
    data.command = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [torque]
    data.torque = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [setPoint_1]
    data.setPoint_1 = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [setPoint_2]
    data.setPoint_2 = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [state]
    data.state = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [motorsCurrent]
    data.motorsCurrent = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [capSensorVal]
    data.capSensorVal = _deserializer.int16(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 15;
  }

  static datatype() {
    // Returns string type for a message object
    return 'promobot_msgs/ServoSmallState';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '06a729f881bbfd241cb1c26dff3c2b05';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int16 id				# ID сервы
    uint16 command			# Регистр команд
    bool torque        		# Разрешение работы двигателя
    int16 setPoint_1      	# Установка задачи сервоприводу 1
    int16 setPoint_2      	# Установка задачи сервоприводу 2
    uint16 state		    # Статус сервопривода
    int16 motorsCurrent		# Общий ток на двигателе
    int16 capSensorVal		# Показания емкостного датчика
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ServoSmallState(null);
    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = 0
    }

    if (msg.command !== undefined) {
      resolved.command = msg.command;
    }
    else {
      resolved.command = 0
    }

    if (msg.torque !== undefined) {
      resolved.torque = msg.torque;
    }
    else {
      resolved.torque = false
    }

    if (msg.setPoint_1 !== undefined) {
      resolved.setPoint_1 = msg.setPoint_1;
    }
    else {
      resolved.setPoint_1 = 0
    }

    if (msg.setPoint_2 !== undefined) {
      resolved.setPoint_2 = msg.setPoint_2;
    }
    else {
      resolved.setPoint_2 = 0
    }

    if (msg.state !== undefined) {
      resolved.state = msg.state;
    }
    else {
      resolved.state = 0
    }

    if (msg.motorsCurrent !== undefined) {
      resolved.motorsCurrent = msg.motorsCurrent;
    }
    else {
      resolved.motorsCurrent = 0
    }

    if (msg.capSensorVal !== undefined) {
      resolved.capSensorVal = msg.capSensorVal;
    }
    else {
      resolved.capSensorVal = 0
    }

    return resolved;
    }
};

module.exports = ServoSmallState;
