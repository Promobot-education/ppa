#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy
import roslib
from std_msgs.msg import *
from promobot_msgs.msg import *
from promobot_srvs.srv import *

#############################################################
#############################################################
class TorqueControl():
#############################################################
#############################################################

    #############################################################
    def __init__(self):
    #############################################################
        rospy.init_node("torque_control")
        self.nodename = rospy.get_name()
        rospy.loginfo("%s starting" % self.nodename)
        #rospy.sleep(5)


        self.servos             = ServoStates()
        self.in_interaction     = False
        self.left_arm_error     = False
        self.right_arm_error    = False
        self.head_error         = False
        self.torso_error        = False

        self.left_arm_logged    = False
        self.right_arm_logged   = False
        self.head_logged        = False
        self.torso_logged       = False

        self.is_calibrated      = False
        self.is_paused          = False
        self.is_pause_locked    = False
        self.is_started         = False

        self.all_servos_rebooted    = 0
        self.is_depthcamera_enabled = False

        self.left_arm_obst_error = False
        self.right_arm_obst_error = False

        rospy.wait_for_service('/parameter_server/is_started')
        self.is_parameter_srv = rospy.ServiceProxy('/parameter_server/is_started', Bool)
        is_parameter_started = False
        while not is_parameter_started:
            try:
                parameter_started_resp  = self.is_parameter_srv()
                is_parameter_started    = parameter_started_resp.ok
            except rospy.ServiceException as e:
                rospy.logerr("Service call failed: %s", e)
            if not is_parameter_started:
                rospy.sleep(1)

        rospy.Subscriber('/drive/pause', std_msgs.msg.Bool, self.drivePauseCallback)
        self.pub_pause = rospy.Publisher('/torque/drive/pause', std_msgs.msg.Bool, queue_size=20, latch=True)

        self.left_arm_joints        = rospy.get_param('/left_arm_controller/joints')
        self.right_arm_joints       = rospy.get_param('/right_arm_controller/joints')
        self.torso_joints           = rospy.get_param('/torso_controller/joints')
        self.head_joints            = rospy.get_param('/head_controller/joints')
        self.min_dist_front_up      = rospy.get_param('/driving/minDistFrontUp')
        self.min_dist_front_down    = rospy.get_param('/driving/minDistFrontDown')
        self.use_depth_sensors      = rospy.get_param('/driving/useDepthSensors')

        self.max_calibration_count  = rospy.get_param('/torque_control/maxCalibrationCount', 3)

#        rospy.wait_for_service('/tts/start')
        rospy.wait_for_service('/promobot_servos/torque')
        rospy.wait_for_service('/promobot_servos/is_calibrated')
        rospy.wait_for_service('/promobot_servos/calibration_reset')

        try:
#            self.tts_srv            = rospy.ServiceProxy('/tts/start', TTSCommand)
            self.servos_torque_srv  = rospy.ServiceProxy('/promobot_servos/torque', setServoTorque)
            self.is_calibrated_srv  = rospy.ServiceProxy('/promobot_servos/is_calibrated', Bool)
            self.calibration_reset_srv  = rospy.ServiceProxy('/promobot_servos/calibration_reset', Bool)

        except rospy.ServiceException, e:
            rospy.logerr("Service call failed: %s"%e)

        rospy.Subscriber('/promobot_servos/core', ServoStates, self.servosCallback)
        # check calibration
        self.calibration_time = 0
        while self.is_calibrated == False:
            rospy.loginfo("%s. %d" % (self.nodename, self.calibration_time))
            if self.calibration_time > 120:
                self.calibration_time = 0
                if self.all_servos_rebooted > len(self.servos.states) / 2: calibration_resp = self.calibration_reset_srv()
            try:
                resp                = self.is_calibrated_srv()
                self.is_calibrated  = resp.ok
            except rospy.ServiceException, e:
                rospy.logerr("Service call failed: %s"%e)
            self.calibration_time += 1
            rospy.sleep(1)
        self.calibration_time = 0

        rospy.wait_for_service('/script/start')
        try:
            self.script_srv  = rospy.ServiceProxy('/script/start', Script)
        except rospy.ServiceException, e:
            rospy.logerr("Service call failed: %s"%e)

        self.rate = rospy.get_param("~rate", 1)
        self.timeout = rospy.get_param("~timeout", 5)
        self.timeout_ticks = rospy.get_param("~timeout_ticks", self.rate * self.timeout)


        self.pub_cancel_right_arm = rospy.Publisher('/promobot_servos/cancel/right_arm', std_msgs.msg.Empty, queue_size=5)
        self.pub_cancel_left_arm = rospy.Publisher('/promobot_servos/cancel/left_arm', std_msgs.msg.Empty, queue_size=5)
        self.pub_cancel_head = rospy.Publisher('/promobot_servos/cancel/head', std_msgs.msg.Empty, queue_size=5)
        self.pub_cancel_torso = rospy.Publisher('/promobot_servos/cancel/torso', std_msgs.msg.Empty, queue_size=5)

        self.pub_enable_right_arm = rospy.Publisher('/promobot_servos/enable/right_arm', std_msgs.msg.Empty, queue_size=5)
        self.pub_enable_left_arm = rospy.Publisher('/promobot_servos/enable/left_arm', std_msgs.msg.Empty, queue_size=5)

        self.pub_cancel_script = rospy.Publisher('/script/cancel', std_msgs.msg.Empty, queue_size=5)

            
        self.is_started = True
        rospy.loginfo("%s started successful" % self.nodename)

    #############################################################
    def spin(self):
    #############################################################
        r = rospy.Rate(self.rate)
        idle = rospy.Rate(1)
        self.ticks_since_target = self.timeout_ticks

        ###### main loop  ######
        while not rospy.is_shutdown():
            self.spinOnce()
            r.sleep()


    #############################################################
    def spinOnce(self):
    #############################################################
        if self.is_calibrated:
            if (self.left_arm_error or self.right_arm_error or self.head_error or self.torso_error):
#                rospy.loginfo("%d ticks" % self.ticks_since_target)
                self.ticks_since_target += 1
                if (self.ticks_since_target > self.timeout_ticks):
                    self.ticks_since_target = 0
                    if self.in_interaction == False:
                        # run script
                        script_started = True
#                        script_started = False
#                        try:
#                            script_resp     = self.script_srv('{\"parts\": [{\"neck\": [{\"command\": \"sleep 0.0\",\"id\": 0}]}]}')
#                            script_started  = script_resp.ok
#                        except rospy.ServiceException, e:
#                            rospy.logerr("Service call failed: %s"%e)
#                        rospy.loginfo("script_started %s" % script_started)


                        if script_started == True:

                            rospy.sleep(1)
                            text = 'пожалуйста, отойдите на пару шагов, мне нужно размяться'

                            obstacle = False


                            if obstacle == False:

                                # run script
                                is_script = False
                                while is_script == False:
                                    try:
                                        script_name = ''
                                        if self.left_arm_obst_error or self.right_arm_obst_error: script_name = 'zero_arms'
                                        else: script_name = 'zero_all_servos'
                                        script_resp     = self.script_srv(script_name)
                                        is_script  = script_resp.ok
                                    except rospy.ServiceException, e:
                                        rospy.logerr("Service call failed: %s"%e)

                                # reset calibration
                                rospy.sleep(2)
                                rospy.loginfo('reset calibration')
                                self.is_calibrated = False

                                rospy.loginfo("left_obst_error %s, right_obst_error  %s" % (self.left_arm_obst_error, self.right_arm_obst_error))
                                if self.left_arm_obst_error: self.pub_enable_left_arm.publish(std_msgs.msg.Empty())
                                if self.right_arm_obst_error: self.pub_enable_right_arm.publish(std_msgs.msg.Empty())
                                if( not self.left_arm_obst_error and not self.right_arm_obst_error): calibration_resp = self.calibration_reset_srv()

                                self.is_pause_locked = True
                                msg_pause = std_msgs.msg.Bool()
                                msg_pause.data = True
                                self.pub_pause.publish(msg_pause)

                                rospy.sleep(1)

                                # call tts
                                text = 'Начинаю калибровку рук'
                                rospy.loginfo("say  %s" % text)
#                                self.tts_srv(text, False)

                                # check calibration
                                self.calibration_time   = 0
                                self.count              = 0

                                while self.is_calibrated == False:
                                    if self.calibration_time > 120:
                                        rospy.logerr("%s. calibration is to long." % self.nodename)
                                        self.calibration_time = 0
                                        self.count += 1
                                    try:
                                        resp                = self.is_calibrated_srv()
                                        self.is_calibrated  = resp.ok
                                    except rospy.ServiceException, e:
                                        rospy.logerr("Service call failed: %s"%e)

                                    self.calibration_time += 1
                                    rospy.sleep(1)
                                    rospy.loginfo('calibrating')

                                self.pub_cancel_script.publish(std_msgs.msg.Empty())

                                msg_pause.data = self.is_paused
                                self.pub_pause.publish(msg_pause)
                                self.is_pause_locked = False

                                self.calibration_time = 0
                                self.left_arm_error     = False
                                self.right_arm_error    = False
                                self.head_error         = False
                                self.torso_error        = False
                                self.left_arm_obst_error = False
                                self.right_arm_obst_error = False

                                self.left_arm_logged    = False
                                self.right_arm_logged   = False
                                self.head_logged        = False
                                self.torso_logged       = False
            else:
                self.ticks_since_target = self.timeout_ticks
                rospy.loginfo('all clear')

    #############################################################
    def servosCallback(self,msg):
    #############################################################
        self.servos = msg

        self.all_servos_rebooted = len([ (True) for servo in msg.states if 'REBOOTED' in servo.fault_code_str])

        for servo in msg.states:                
            if(servo.fault_code > 0 and self.is_started ):
                if(servo.name in self.left_arm_joints) and (self.left_arm_error == False):
                    self.left_arm_error = True
                    if self.left_arm_logged == False:
                        self.left_arm_logged = True
                        rospy.logerr("%s error on %s -> %s" % (self.nodename, servo.name, servo.fault_code_str))
#                    self.changeTorque(self.left_arm_joints,     False)
                    self.is_pause_locked = True
                    msg_pause = std_msgs.msg.Bool()
                    msg_pause.data = True
                    self.pub_pause.publish(msg_pause)
                    if('OBSTACLE_DETECTED' in servo.fault_code_str): self.left_arm_obst_error = True
                    else: self.pub_cancel_left_arm.publish(std_msgs.msg.Empty())

                if(servo.name in self.right_arm_joints) and (self.right_arm_error == False):
                    self.right_arm_error = True
                    if self.right_arm_logged == False:
                        self.right_arm_logged = True
                        rospy.logerr("%s error on %s -> %s" % (self.nodename, servo.name, servo.fault_code_str))
#                    self.changeTorque(self.right_arm_joints,    False)
                    self.is_pause_locked = True
                    msg_pause = std_msgs.msg.Bool()
                    msg_pause.data = True
                    self.pub_pause.publish(msg_pause)
                    if('OBSTACLE_DETECTED' in servo.fault_code_str): self.right_arm_obst_error = True
                    else: self.pub_cancel_right_arm.publish(std_msgs.msg.Empty())

                if(servo.name in self.head_joints) and (self.head_error == False):
                    self.head_error = True
                    if self.head_logged == False:
                        self.head_logged = True
                        rospy.logerr("%s error on %s -> %s" % (self.nodename, servo.name, servo.fault_code_str))
#                    self.changeTorque(self.head_joints,         False)
                    self.pub_cancel_head.publish(std_msgs.msg.Empty())

                if(servo.name in self.torso_joints) and (self.torso_error == False):
                    self.torso_error = True
                    if self.torso_logged == False:
                        self.torso_logged = True
                        rospy.logerr("%s error on %s -> %s" % (self.nodename, servo.name, servo.fault_code_str))
#                    self.changeTorque(self.torso_joints,        False)
                    self.pub_cancel_torso.publish(std_msgs.msg.Empty())

    #############################################################
    def changeTorque(self, joints, value):
    #############################################################
        for servo in self.servos.states:
            if(servo.name in joints):
                if servo.torque is not value:
                    rospy.loginfo("%s change torque on %s to %s" % (self.nodename, servo.name, value))
                    resp = self.servos_torque_srv(servo.id, value)

    #############################################################
    def interactionCallback(self,msg):
    #############################################################
        self.in_interaction = msg.state


    #############################################################
    def drivePauseCallback(self,msg):
    #############################################################
        rospy.loginfo("%s recived drive pause %s" % (self.nodename, msg.data))
        self.is_paused = msg.data
        if self.is_pause_locked == False:
            msg_pause = std_msgs.msg.Bool()
            msg_pause.data = self.is_paused
            rospy.loginfo("%s sending drive pause %s" % (self.nodename, self.is_paused))
            self.pub_pause.publish(msg_pause)
    #############################################################
    def depthCameraEnabledCallback(self,msg):
    #############################################################
        self.is_depthcamera_enabled = msg.data

#############################################################
#############################################################
if __name__ == '__main__':
    """ main """
    try:
        torqueControl = TorqueControl()
        torqueControl.spin()
    except rospy.ROSInterruptException:
        pass
