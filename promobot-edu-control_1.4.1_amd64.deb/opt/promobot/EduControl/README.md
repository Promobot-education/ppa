# EduControl

## Команда при самом первом запуске EduControl:

echo "source /opt/promobot/EduControl/install/setup.bash" >> ~/.bashrc

## Команда для запуска симуляции:

roslaunch promobot_control start_simulation.launch side:=left  
или  
roslaunch promobot_control start_simulation.launch side:=right


## Команды для работы с реальным устройством

roslaunch promobot_control promobot_hardware.launch side:=left  
или  
roslaunch promobot_control promobot_hardware.launch side:=right

