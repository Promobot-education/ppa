#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy
from promobot_srvs.srv import Bool
from std_msgs.msg import Int32


class JointNullManager():
    def __init__(self):
        self._null_positions = (0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        self._client_count = 0
        self.side = rospy.get_param('/rooky_info/side')
        rospy.init_node('joint_null_manager', anonymous=True)
        rospy.Subscriber("client_count", Int32, self._callback)
        rospy.wait_for_service('/{0}_arm_controller/null_joints'.format(self.side))
        try:
            self.null_joints_srv = rospy.ServiceProxy('/{0}_arm_controller/null_joints'.format(self.side), Bool)
        except rospy.ServiceException as e:
            rospy.logerr("Service call failed: %s" % e)

    def _callback(self, data):
        if data.data == self._client_count:
            return

        self._client_count = data.data
        if self._client_count == 0:
            self.null_joints_srv()

    def spin(self):
        rospy.spin()


if __name__ == '__main__':
    node = JointNullManager()
    node.spin()
