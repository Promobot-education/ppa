#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy
from std_msgs.msg import *
from trajectory_msgs.msg import *
from promobot_srvs.srv import *

TIME_TO_RESET = 5


class JointResetter():
    def __init__(self):
        self._null_positions = (0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        self._client_count = 0
        self._side = rospy.get_param('/rooky_info/side')
        rospy.init_node('null_joints_srv')
        rospy.Service('/{0}_arm_controller/null_joints'.format(self._side), Bool, self.handler)
        self._publisher = rospy.Publisher('{0}_arm_controller/command'.format(self._side),
                                          JointTrajectory,
                                          queue_size=1)

    def _construct_joint_names(self, side):
        joint_names = ([""])
        for num in range(1, 8):
            name = (["{0}_arm_{1}_joint".format(side, str(num))])
            joint_names += name
        return joint_names[1:]

    def handler(self, req):
        self.reset_all_joints()
        return BoolResponse(True)

    def reset_all_joints(self):
        rospy.loginfo("NULL_JOINTS")
        point = JointTrajectoryPoint()
        point.positions = self._null_positions
        point.time_from_start = rospy.Duration(TIME_TO_RESET)

        traj_msg = JointTrajectory()
        traj_msg.joint_names = self._construct_joint_names(self._side)
        traj_msg.points.append(point)

        self._publisher.publish(traj_msg)

    def spin(self):
        rospy.spin()


if __name__ == '__main__':
    node = JointResetter()
    node.spin()
