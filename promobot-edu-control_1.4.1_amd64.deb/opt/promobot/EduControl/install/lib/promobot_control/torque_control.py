#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy
import roslib
from std_msgs.msg import *
from promobot_msgs.msg import *
from promobot_srvs.srv import *


class TorqueControl():
    def __init__(self):
        rospy.init_node("torque_control")
        self.nodename = rospy.get_name()
        rospy.loginfo("%s starting" % self.nodename)
        # rospy.sleep(5)

        self.servos = ServoStates()
        self.in_interaction = False
        self.arm_error = False

        self.arm_logged = False

        self.is_calibrated = False
        self.is_paused = False
        self.is_started = False

        self.rebooted_servos_count = 0
        self.arm_obst_error = False

        self.side = rospy.get_param('/rooky_info/side')
        self.arm_joints = rospy.get_param(
            '/{0}_arm_controller/joints'.format(self.side))

        self.max_calibration_count = rospy.get_param(
            '/torque_control/maxCalibrationCount', 3)

        rospy.wait_for_service('/promobot_servos/torque')
        rospy.wait_for_service('/promobot_servos/is_calibrated')
        rospy.wait_for_service('/promobot_servos/calibration_reset')
        rospy.wait_for_service('/{0}_arm_controller/null_joints'.format(self.side))

        try:
            self.servos_torque_srv = rospy.ServiceProxy(
                '/promobot_servos/torque', setServoTorque)
            self.is_calibrated_srv = rospy.ServiceProxy(
                '/promobot_servos/is_calibrated', Bool)
            self.calibration_reset_srv = rospy.ServiceProxy(
                '/promobot_servos/calibration_reset', Bool)
            self.null_joints_srv = rospy.ServiceProxy(
                '/{0}_arm_controller/null_joints'.format(self.side), Bool)
        except rospy.ServiceException as e:
            rospy.logerr("Service call failed: %s" % e)

        rospy.Subscriber('/promobot_servos/core', ServoStates, self.servosCallback)
        # check calibration
        self.calibration_time = 0
        while self.is_calibrated == False:
            rospy.loginfo("%s. %d" % (self.nodename, self.calibration_time))
            if self.calibration_time > 120:
                self.calibration_time = 0
                if self.rebooted_servos_count > len(self.servos.states) / 2:
                    calibration_resp = self.calibration_reset_srv()
            try:
                resp = self.is_calibrated_srv()
                self.is_calibrated = resp.ok
            except rospy.ServiceException as e:
                rospy.logerr("Service call failed: %s" % e)
            self.calibration_time += 1
            rospy.sleep(1)
        self.calibration_time = 0

        self.rate = rospy.get_param("~rate", 1)
        self.timeout = rospy.get_param("~timeout", 5)
        self.timeout_ticks = rospy.get_param(
            "~timeout_ticks", self.rate * self.timeout)

        self.pub_enable_arm = rospy.Publisher(
            '/promobot_servos/enable/{0}_arm'.format(self.side), std_msgs.msg.Empty, queue_size=5)

        self.is_started = True
        rospy.loginfo("%s started successful" % self.nodename)

    def spin(self):
        r = rospy.Rate(self.rate)
        self.ticks_since_target = self.timeout_ticks

        while not rospy.is_shutdown():
            self.spinOnce()
            r.sleep()

    def spinOnce(self):
        if not self.is_calibrated:
            return
        if self.arm_error:
            self.ticks_since_target += 1
            if self.ticks_since_target < self.timeout_ticks:
                return

            self.ticks_since_target = 0
            if self.in_interaction == True:
                return

            # reset calibration
            rospy.sleep(5)
            rospy.loginfo('reset calibration')
            self.is_calibrated = False

            rospy.loginfo("obstacle_error %s" % (self.arm_obst_error))
            self.calibration_reset_srv()

            rospy.sleep(1)

            try:
                self.null_joints_srv()
            except rospy.ServiceException as e:
                rospy.logerr("Service call failed: %s" % e)

            # check calibration
            self.calibration_time = 0
            self.count = 0
            while self.is_calibrated == False:
                if self.calibration_time > 120:
                    rospy.logerr("%s. calibration is to long." % self.nodename)
                    self.calibration_time = 0
                    self.count += 1
                try:
                    resp = self.is_calibrated_srv()
                    self.is_calibrated = resp.ok
                except rospy.ServiceException as e:
                    rospy.logerr("Service call failed: %s" % e)

                self.calibration_time += 1
                rospy.sleep(1)

            self.calibration_time = 0
            self.arm_error = False
            self.arm_obst_error = False
            self.arm_logged = False
        else:
            self.ticks_since_target = self.timeout_ticks

    def servosCallback(self, msg):
        self.servos = msg

        self.rebooted_servos_count = len(
            [(True) for servo in msg.states if 'REBOOTED' in servo.fault_code_str])

        for servo in msg.states:
            if servo.fault_code == 0 or not self.is_started:
                continue

            if "COMMUNICATION" in servo.fault_code_str:
                continue

            if "OVERCURRENT" in servo.fault_code_str:
                self.arm_obst_error = True

            if servo.name not in self.arm_joints or self.arm_error == True:
                continue

            self.arm_error = True
            if not self.arm_logged:
                self.arm_logged = True
                rospy.logerr("%s error on %s -> %s" %
                                (self.nodename, servo.name, servo.fault_code_str))
            self.changeTorque(self.arm_joints, False)

    def changeTorque(self, joints, value):
        for servo in self.servos.states:
            if servo.name not in joints:
                continue
            if servo.torque == value:
                continue
            rospy.loginfo("%s change torque on %s to %s" %
                          (self.nodename, servo.name, value))
            self.servos_torque_srv(servo.id, value)


if __name__ == '__main__':
    """ main """
    try:
        torqueControl = TorqueControl()
        torqueControl.spin()
    except rospy.ROSInterruptException:
        pass
