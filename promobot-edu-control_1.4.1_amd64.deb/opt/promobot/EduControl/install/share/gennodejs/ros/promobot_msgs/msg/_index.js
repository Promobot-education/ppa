
"use strict";

let HallSensors = require('./HallSensors.js');
let PowerValue = require('./PowerValue.js');
let Angles = require('./Angles.js');
let Error = require('./Error.js');
let ID = require('./ID.js');
let PowerValueArray = require('./PowerValueArray.js');
let ScriptProcess = require('./ScriptProcess.js');
let Servo = require('./Servo.js');
let ServoSmallState = require('./ServoSmallState.js');
let ServoState = require('./ServoState.js');
let ServoStates = require('./ServoStates.js');
let TouchSens = require('./TouchSens.js');

module.exports = {
  HallSensors: HallSensors,
  PowerValue: PowerValue,
  Angles: Angles,
  Error: Error,
  ID: ID,
  PowerValueArray: PowerValueArray,
  ScriptProcess: ScriptProcess,
  Servo: Servo,
  ServoSmallState: ServoSmallState,
  ServoState: ServoState,
  ServoStates: ServoStates,
  TouchSens: TouchSens,
};
